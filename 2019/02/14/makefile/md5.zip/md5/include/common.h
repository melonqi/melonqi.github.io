#ifndef _COMMON_H
#define _COMMON_H
#include <string>

std::string get_string_MD5(const std::string str); 

#endif
