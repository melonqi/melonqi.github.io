#include <iostream>
#include "common.h"

using namespace std;

int main()
{
	string str = "1234";
	string after = get_string_MD5(str);
	cout<<"Before MD5: "<<str<<endl;
	cout<<"After MD5: "<<after<<endl;
	return 0;
}
