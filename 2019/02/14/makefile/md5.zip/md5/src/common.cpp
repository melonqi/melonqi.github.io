#include "common.h"
#include <openssl/md5.h>
#include <string.h>
#include <stdio.h>
std::string get_string_MD5(const std::string str)
{
	MD5_CTX ctx;
	char *data = (char *)str.c_str();
	unsigned char md[16]={0};
	char buf[33]={0};
	char tmp[3]={0};
	int i;
	
	MD5_Init(&ctx);
	MD5_Update(&ctx,data,strlen(data));
	MD5_Final(md,&ctx);

	for(i=0;i<16;i++)
	{
		sprintf(tmp,"%X",md[i]);
		strcat(buf,tmp);
	}
	return std::string(buf);
}
